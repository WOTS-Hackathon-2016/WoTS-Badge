﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using Windows.UI.Core;
using Windows.UI.Popups;


// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace WotsBadgeUWP
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
        }

        WotsBadge badge = new WotsBadge();

        /// <summary>
        /// connect button click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void btnConnect_Click(object sender, RoutedEventArgs e)
        {
            // get id from textbox
            string text = tbCode.Text;

            // some basic checks
            if ( string.IsNullOrEmpty( text ) )
            {
                // user didn't type anything? let's make it zero...
                text = "0000";
                tbCode.Text = text;
            }

            if ( text.Length < 4 )
            {
                // add some zeroes in front of the text in case it isn't four chars.
                while (text.Length < 4) text = "0" + text;
                tbCode.Text = text;
            }

            bool success = await badge.ConnectAsync("WoTS-" + text);

            if ( success )
            {
                success = await badge.sendTimeAsync(DateTime.Now);

                if (!success)
                {
                    // Disconnected..
                    await new MessageDialog("A problem occured, try to reconnect...").ShowAsync();
                }
            }

            if (success)
            {
                // go to the text window
                pivot.SelectedItem = pivText;
            }
        }


        private async void btnText_Click(object sender, RoutedEventArgs e)
        {
            string text = tbText.Text;
            bool success = await badge.sendTextAsync(text);

            // Disconnected..
            if (!success)
            {
                pivot.SelectedItem = pivConnect;
                await new MessageDialog("A problem occured, try to reconnect...").ShowAsync();
            }
        }

        private void tbText_KeyDown(object sender, KeyRoutedEventArgs e)
        {
            if ( e.Key == Windows.System.VirtualKey.Enter )
            {
                btnText_Click(null, null);
            }
        }

        private void tbCode_KeyDown(object sender, KeyRoutedEventArgs e)
        {
            if (e.Key == Windows.System.VirtualKey.Enter)
            {
                btnConnect_Click(null, null);
            }
        }
    }
}
