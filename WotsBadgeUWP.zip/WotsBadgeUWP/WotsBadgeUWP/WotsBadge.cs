﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Windows.Devices.Bluetooth.GenericAttributeProfile;
using Windows.Storage.Streams;
using Windows.Devices.Bluetooth;
using Windows.Devices.Bluetooth.Advertisement;
using Windows.Devices.Enumeration;
using System.Threading.Tasks;

namespace WotsBadgeUWP
{
    public class WotsBadge
    {

        private BluetoothLEDevice badge = null;
        private BluetoothLEAdvertisementWatcher watcher = null;
        private GattDeviceService uartService;
        private GattCharacteristic uartTx;
        private ulong bleAddress = 0;
        private bool found = false;
        string deviceName = null;

        public WotsBadge()
        {

        }

        public async Task<bool> ConnectAsync(string name)
        {
            bool success = false;

            deviceName = name;

            if ( badge != null )
            {
                badge.Dispose();
                badge = null;
            }

            // create a filter for advertising packets
            BluetoothLEAdvertisement nameFilter = new BluetoothLEAdvertisement();
            nameFilter.LocalName = name;

            // check if the device is advertising
            BluetoothLEAdvertisementFilter adFilter = new BluetoothLEAdvertisementFilter();
            adFilter.Advertisement = nameFilter;
            watcher = new BluetoothLEAdvertisementWatcher(adFilter);
            watcher.Received += Watcher_Received;
            found = false;
            watcher.Start();
            // ugly way to get a timeout and wait for an event.. 
            for (int i = 0; (i < 30) && (!found); i++) await Task.Delay(100);
            // found device or timed out..
            watcher.Stop();

            if (found)
            {
                success = true;

                // connect 
                badge = await BluetoothLEDevice.FromBluetoothAddressAsync(bleAddress);

                // pair if we have to (we are already connected!)
                if (!badge.DeviceInformation.Pairing.IsPaired)
                {
                    // not paired yet, so pair it...
                    var result = await badge.DeviceInformation.Pairing.PairAsync(DevicePairingProtectionLevel.None);
                    // should be paired now

                    if ( result.Status != DevicePairingResultStatus.Paired )
                    {
                        success = false;
                    }
                }

                uartService = null;
                uartTx = null;

                // getting the service seems to always fail after first initial paring.
                // I am hoping that the problem can be fixed by giving windows some time...
                if (success)
                {
                    success = false;
                    for (int i = 0; i < 20; i++)
                    {
                        try
                        {
                            // get the UART service
                            // First get the characteristic you're interested in    
                            var txCharacteristicId = new Guid("6E400002-B5A3-F393-E0A9-E50E24DCCA9E");
                            var rxCharacteristicId = new Guid("6E400003-B5A3-F393-E0A9-E50E24DCCA9E");
                            var uartServiceId = new Guid("6E400001-B5A3-F393-E0A9-E50E24DCCA9E");
                            uartService = badge.GetGattService(uartServiceId);
                            uartTx = uartService.GetCharacteristics(txCharacteristicId)[0];
                        }
                        catch
                        {
                            // disconnect
                            badge.Dispose();

                            // wait
                            await Task.Delay(100);

                            // reconnect
                            badge = await BluetoothLEDevice.FromBluetoothAddressAsync(bleAddress);
                        }

                        if ((null != uartService) && (null != uartTx))
                        {
                            success = true;
                            break;
                        }
                    }
                }



            }

            return success;
        }

        private void Watcher_Received(BluetoothLEAdvertisementWatcher sender, BluetoothLEAdvertisementReceivedEventArgs args)
        {
            // this should not be nescessary! we are using a filter!
            if (args.Advertisement.LocalName == deviceName )
            {
                bleAddress = args.BluetoothAddress;
                found = true;
            }
        }

        public async Task<bool> sendTextAsync( string text )
        {
            bool success = true;

            try
            {
                text = text.Replace(')', ']');
                text = text.Replace('(', '[');
                text = "TEXT(" + text + ")";

                // send text
                for ( int i = 0; i < text.Length; i += 20 )
                {                    
                    DataWriter writer = new DataWriter();
                    writer.WriteString((i + 20 < text.Length ) ? text.Substring( i,20 ) : text.Substring( i ) );
                    await uartTx.WriteValueAsync(writer.DetachBuffer());
                }
            }
            catch
            {
                // disconnected?
                success = false;
            }

            return success;
        }

        string B32 = "0123456789ABCDEFGHJKLMNPQRSTUVWX";
        private bool checkBase32( string text )
        {
            bool result = true;

            // this is inefficient and needs to be replaced by something nicer...
            for ( int i = 0; i < text.Length; i++ )
            {
                if ( B32.IndexOf( text[0] ) == -1 )
                {
                    result = false;
                    break;
                }
            }

            return result;
        }

        public async Task<bool> sendImageAsync(string image)
        {
            bool success = true;

            try
            {
                image = image.ToUpper();

                if (checkBase32(image))
                {
                    image = "IMAGE(" + image + ")";

                    // send text
                    for (int i = 0; i < image.Length; i += 20)
                    {
                        DataWriter writer = new DataWriter();
                        writer.WriteString((i + 20 < image.Length) ? image.Substring(i, 20) : image.Substring(i));
                        await uartTx.WriteValueAsync(writer.DetachBuffer());
                    }
                }
                else
                {
                    // this is a programming error - not a connection problem.
                    throw new FormatException("image is not a base32 string");
                }
            }
            catch
            {
                // disconnected?
                success = false;
            }

            return success;
        }

        public async Task<bool> sendLiveAsync(string image)
        {
            bool success = true;

            try
            {
                image = image.ToUpper();

                // don't want scrolling live images
                if (image.Length >= 17) image = image.Substring(0, 17);

                if (checkBase32(image))
                {
                    image = "LIVE(" + image + ")";

                    // send text
                    for (int i = 0; i < image.Length; i += 20)
                    {
                        DataWriter writer = new DataWriter();
                        writer.WriteString((i + 20 < image.Length) ? image.Substring(i, 20) : image.Substring(i));
                        await uartTx.WriteValueAsync(writer.DetachBuffer());
                    }
                }
                else
                {
                    // this is a programming error - not a connection problem.
                    throw new FormatException("image is not a base32 string");
                }
            }
            catch
            {
                // disconnected?
                success = false;
            }

            return success;
        }

        public async Task<bool> sendTimeAsync( DateTime now )
        {
            bool success = true;

            try
            {
                string text = "SETTIME(" + now.ToString("HH:mm") + "," + ((((int)(now.DayOfWeek)) + 1) % 7).ToString() + ")";

                // sync the time
                DataWriter writer = new DataWriter();
                writer.WriteString(text);
                await uartTx.WriteValueAsync(writer.DetachBuffer());
            }
            catch
            {
                // disconnected?
                success = false;
            }

            return success;
        }

        public void disconnect()
        {
            if ( null != badge )
            {
                // the dispose will cause the disconnect.
                badge.Dispose();
                badge = null;
            }
        }

    }
}